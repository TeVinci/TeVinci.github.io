<?php

$dbServername = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "cospace_login";

$conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);
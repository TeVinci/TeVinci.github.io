<?php 
	include '../HF/innerheader.php'
 ?>

</body>

 <?php 
 include '../HF/innerfooter.php'
  ?>
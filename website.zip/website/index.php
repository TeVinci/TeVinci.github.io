
<?php
include 'outerheader.php';
?>
		<div class='form-wrapper'>
			<div class="signuptext">
				<a href="signup.php"><h2>SignUp</h2></a>
			</div>
		</div>
<?php
include 'outerfooter.php';
?>
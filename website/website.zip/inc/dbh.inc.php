<?php

$dbServername = "185.27.134.11";
$dbUsername = "cmsho_20889444";
$dbPassword = "";
$dbName = "cmsho_20889444_CoSpace";

$conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);

